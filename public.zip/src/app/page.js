import Home from "../app/pages/home/page";
export default function page() {

  return (
    <>
      <Home />
    </>
  );
}

import EvaluationForm from '@/app/components/EvaluationForm';
function page() {

  return (
    <div>
      <EvaluationForm />
    </div>
  )
}

export default page;